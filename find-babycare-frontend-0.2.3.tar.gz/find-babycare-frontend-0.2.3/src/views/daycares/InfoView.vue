<template>
  Daycares Info View
</template>
