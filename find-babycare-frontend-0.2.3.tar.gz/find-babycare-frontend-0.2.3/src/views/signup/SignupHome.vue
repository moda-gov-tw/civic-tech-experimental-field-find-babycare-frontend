<script setup>
import SignupPanel from '../../components/SignupPanel.vue';
</script>

<template>
  <SignupPanel />
</template>
