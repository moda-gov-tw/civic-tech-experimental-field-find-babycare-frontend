<template>
  Register View
  <RouterView />
</template>
