<template>
  <button>
    <CheckBoxField
      text="公設民營"
    />
  </button>
</template>

<script setup>
import CheckBoxField from '../form/CheckBoxField.vue';
</script>
