// 入托狀態
export const ENROLLMENT_STATUS = [
 'ENROLLED', // 0 入托中
 'GRADUATED', // 1 已退托
];
